from dotenv import load_dotenv

load_dotenv()


def load_env():
    return True
